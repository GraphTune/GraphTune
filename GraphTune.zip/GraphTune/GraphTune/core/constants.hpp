

#ifndef CONSTANTS_H
#define CONSTANTS_H

#define CHUNKSIZE 1048576
// #define PAGESIZE 4096
#define IOSIZE 1048576 * 24

#endif
